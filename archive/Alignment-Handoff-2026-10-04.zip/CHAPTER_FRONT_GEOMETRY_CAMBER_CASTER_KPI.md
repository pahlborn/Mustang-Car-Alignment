# Mustang Track Chassis Setup
# Kapitel: Vorderachsgeometrie — Camber, Castor, KPI/SAI

**Fahrzeug:** Ford Mustang 1966 – Rundstrecke  
**Version:** 0.1 – 2026-10-04  
**Status:** Fachkapitel; GitHub unverändert

---

## 1. Warum Camber, Castor und KPI zusammengehören

Diese drei Größen beschreiben gemeinsam die räumliche Lage des Rades und der Lenkachse:

- **Camber**: Radneigung in Vorderansicht
- **Castor**: Lenkachsenneigung in Seitenansicht
- **KPI / SAI**: Lenkachsenneigung in Vorderansicht

Beim 1965/66 Mustang sind sie konstruktiv gekoppelt. Änderungen an UCA-Shims, Strut Rods, LCA-Position, Ride Height oder Ball-Joint-Geometrie können mehr als eine Größe gleichzeitig beeinflussen.

Daher gilt:

> **Nie einen einzelnen Winkel isoliert einstellen und danach davon ausgehen, dass der Rest unverändert geblieben ist.**

---

# 2. Camber

## Definition

Von vorn betrachtet:

- Rad oben nach innen → **negativer Camber**
- Rad oben nach außen → **positiver Camber**

Camber beeinflusst die Lage des Reifenaufstands in Kurvenfahrt.

## Warum negativer Camber auf der Rundstrecke?

In der Kurve:

- Karosserie rollt
- Radaufhängung federt ein/aus
- Reifen verformt sich
- Außenrad trägt hohe Last

Negativer statischer Camber kann dabei helfen, das belastete Außenrad näher an eine günstige Aufstandsfläche zu bringen.

Aber:

> **Mehr negativer Camber ist nicht automatisch mehr Grip.**

Zu viel negativer Camber kann:
- Bremsfläche reduzieren
- Innenkante überlasten
- Reifenverschleiß erhöhen
- Geradeausgrip verschlechtern

Longacre weist darauf hin, dass der optimale statische Camber aus Fahrwerksgeometrie, Pyrometerdaten und realem Testen entstehen muss.

---

# 3. Camber Gain

Camber Gain beschreibt die Camberänderung über Federweg.

Eine statische Einstellung von z. B. −2,0° sagt deshalb allein nicht, welchen Camber das Rad in einer schnellen Kurve tatsächlich hat.

Relevant sind:

- UCA-Winkel
- LCA-Winkel
- Ball-Joint-Positionen
- Ride Height
- Shelby/Arning Drop
- Federweg
- Rollwinkel

Der Shelby Drop dient gerade dazu, die Vorderachs-Kinematik und Camberkurve zu verbessern.

---

# 4. Castor

## Definition

Von der Fahrzeugseite betrachtet ist Castor die Neigung der gedachten Lenkachse durch oberes und unteres Kugelgelenk.

- Lenkachse oben nach hinten geneigt → **positiver Castor**
- oben nach vorn geneigt → negativer Castor

Longacre bestätigt:

- positiver Castor verbessert Richtungsstabilität und Selbstzentrierung
- sehr hoher positiver Castor erhöht die Lenkkräfte

Das ist bei **manueller Lenkung** besonders relevant.

---

# 5. Castor erzeugt dynamischen Camber

Beim Lenken führt positiver Castor dazu, dass sich die Radneigung verändert.

Das kurvenäußere und kurveninnere Rad erhalten beim Lenkeinschlag unterschiedliche Camberänderungen.

Darum ist Castor nicht nur ein Geradeauslauf-Thema, sondern Teil der Kurvengeometrie.

Für Track-Setup muss deshalb gemeinsam betrachtet werden:

- statischer Camber
- positiver Castor
- Lenkwinkel
- Camber Gain

---

# 6. KPI / SAI

KPI = King Pin Inclination  
SAI = Steering Axis Inclination

Bei Kugelgelenk-Vorderachsen ist damit die gedachte Linie durch oberes und unteres Kugelgelenk in Vorderansicht gemeint.

KPI ist beim Mustang primär:

- Geometriegröße
- Diagnosegröße

Nicht der normale Fein-Setup-Regler.

Auffällige Links-/Rechts-Differenzen können auf Geometrieunterschiede hinweisen, z. B.:

- Spindel/Achsschenkel
- Ball Joint
- Querlenker
- Chassis-Aufnahmepunkte
- Montageunterschiede
- Unfallschäden

---

# 7. Included Angle

Der Included Angle verbindet Camber und KPI/SAI.

Er ist diagnostisch interessant, weil Änderungen von Camber bei unverändertem KPI anders zu interpretieren sind als eine Änderung der Lenkachse selbst.

Dieses Thema wird später noch mit einer eindeutigen Vorzeichenkonvention und grafischer Darstellung ergänzt.

---

# 8. Mustang 1965/66 — Einstellmechanismen

## UCA-Shims

Global West beschreibt für 1964–66:

- Shim am **vorderen UCA-Bolzen hinzufügen** → mehr positiver Castor und Camberänderung
- Shim am **hinteren UCA-Bolzen entfernen** → mehr positiver Castor und Camberänderung

Damit sind Castor und Camber über die serienmäßige Shim-Logik gekoppelt.

## Adjustable Strut Rod

Ein kürzer eingestellter Strut Rod zieht den unteren Querlenker nach vorn und erhöht positiven Castor.

Nebenwirkung:

- Rad wandert nach vorn
- Reifen-/Kotflügel-/Valance-Freigängigkeit wird kritischer

## LCA Camber Kit

Das Street or Track LCA Camber Kit erlaubt zusätzliche Camberverstellung am unteren Querlenker.

Vorteil:

- Camber kann stärker unabhängig von der UCA-Shim-Logik verändert werden

Aber:
- Toe anschließend prüfen
- Position des Rades / Geometrie kontrollieren
- Castor erneut verifizieren

---

# 9. Street or Track Track-Beispiel richtig einordnen

Street or Track dokumentiert auf einem eigenen 66-Mustang-Testfahrzeug:

- **−2,75° Camber**
- **+5° Castor**

mit:
- eigenem Tubular UCA
- LCA Camber Kit
- Adjustable Strut Rods

Das ist wertvoll als **technischer Track-Referenzpunkt**, aber kein Zielwert für unser Auto.

Unsere Baseline bleibt zunächst:

- Camber −2,0°
- Castor +3,0°

Bis reale Trackdaten eine Änderung begründen.

---

# 10. Messung mit Dunlop CG/4-5

## Camber — CG/4

1. Fahrzeug race-ready
2. Messfläche geprüft
3. Fahrzeug gesetzt
4. Räder gerade
5. CG/4 an definierter Referenz ansetzen
6. Libelle über Camber-Stellrad zentrieren
7. Wert ablesen
8. links/rechts dokumentieren
9. Messung wiederholen

Die Dunlop-Skala ist additiv. Bei weitergedrehtem Stellrad müssen durchlaufene Teilungen mitgezählt werden.

## Castor / KPI — CG/5 + CG/6

Für jedes Rad:

1. CG/5 spielfrei befestigen
2. CG/6 entriegeln
3. Rad **20° IN**
4. Castor-/KPI-Referenz nullen
5. Rad durch Geradeausstellung auf **20° OUT**
6. Castor-Libelle zentrieren und Wert ablesen
7. KPI-Libelle zentrieren und Wert ablesen
8. dokumentieren
9. wiederholen

Gesamtschwenk: **40°**

---

# 11. "IN" und "OUT" eindeutig

Aus Sicht des jeweils gemessenen Rades:

- **IN**: Vorderkante des Rades Richtung Fahrzeugmitte
- **OUT**: Vorderkante vom Fahrzeug weg

| Rad | IN | OUT |
|---|---|---|
| links | nach rechts | nach links |
| rechts | nach links | nach rechts |

---

# 12. Messfehler

## Camber

Typische Fehler:
- Bodenquerneigung
- Reifenflankenverformung
- Felgen-/Reifenschlag
- Fahrzeug nicht gesetzt
- unterschiedlicher Druck
- ungleiche Beladung

## Castor

Typische Fehler:
- kein exakter 20°-Lenkwinkel
- Drehteller verspannt
- Gauge bewegt sich
- Aufnahme hat Spiel
- Lenkrad/Steering Linkage bewegt sich unkontrolliert
- falsche IN/OUT-Richtung

---

# 13. Einstellstrategie am Mustang

Nicht gleichzeitig an mehreren Stellen drehen.

Empfohlene Logik:

1. **Ride Height und Radlastzustand stabil**
2. Castor grob über Geometrie/UCA + Strut Rod herstellen
3. Camber über vorhandene geeignete Einstellmöglichkeit herstellen
4. Castor erneut prüfen
5. Camber erneut prüfen
6. Toe erst danach final einstellen
7. Bump Steer bei relevanter Geometrieänderung prüfen

---

# 14. Cross-Caster und Cross-Camber

Für eine europäische Rundstrecken-Baseline wird zunächst **symmetrisch** gearbeitet.

Oval-spezifische Empfehlungen, rechts und links absichtlich unterschiedliche Castor-/Camberwerte zu verwenden, werden nicht übernommen.

Erst reale Trackdaten könnten eine asymmetrische Abweichung begründen.

---

# 15. Track-Validierung

## Camber
Beurteilen über:
- Reifentemperatur innen / Mitte / außen
- Warmdruck
- Reifenbild
- Bremsstabilität
- Mid-Corner-Grip

## Castor
Beurteilen über:
- Geradeauslauf
- Lenkrückstellung
- Lenkkräfte
- Turn-in
- Verhalten bei größerem Lenkwinkel

Nie nur eine einzelne Empfindung als Beweis verwenden.

---

# 16. Quellen

- Dunlop CG/4-5 + CG/6 Original Operating Instructions — Nutzer-Scans
- Longacre — Camber Simplified  
  https://longacreracing.com/pages/camber-simplified
- Longacre — Caster Simplified  
  https://longacreracing.com/pages/caster-simplified
- Global West — 1964–66 Mustang +3 Caster Upper Control Arms  
  https://www.globalwest.net/product/mustang-upper-control-arm-3-degree-positive-caster-global-west-1964-1965-1966/
- Street or Track — Tubular +Caster UCA for 65–66 Mustang  
  https://streetortrack.com/street-or-track-tubular-caster-upper-arms

---

# 17. Offene Punkte

- exakte UCA-Ausführung am Fahrzeug
- aktuelle Shim-Pakete links/rechts
- aktuelle Strut-Rod-Längen
- aktuelle LCA-Camber-Kit-Positionen
- reale KPI-Werte
- reale Camber-/Castor-Wiederholbarkeit
- Zusammenhang mit Bump-Steer-Kurve
