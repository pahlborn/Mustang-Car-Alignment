# Mustang Track Chassis Setup — Master Setup Sheet

**Event / Test:**  
**Date:**  
**Track:**  
**Driver:**  
**Session:**  
**Weather:**  
**Air Temp:**  
**Track Temp:**  
**Fuel Start:**  
**Fuel End:**  
**Tire Set ID:**  
**Tire Size:** Avon CR6ZZ 225/65 R15  
**Wheel:** American Racing 15×7  

---

## 1. Race-Ready State

- [ ] Driver / ballast installed
- [ ] Fuel defined
- [ ] Fluids complete
- [ ] Tire pressures set
- [ ] Steering centered
- [ ] Mechanical inspection complete
- [ ] Setup pad verified
- [ ] Suspension settled

---

## 2. Ride Height

| Position | Chassis-to-ground | Chassis-to-wheel-center | Bump stop clearance | Notes |
|---|---:|---:|---:|---|
| LF | | | | |
| RF | | | | |
| LR | | | | |
| RR | | | | |

**Front L-R difference:**  
**Rear L-R difference:**  
**Rake left:**  
**Rake right:**  

---

## 3. Corner Weights

| Position | Weight |
|---|---:|
| LF | |
| RF | |
| LR | |
| RR | |

**Total:**  
**Front %:**  
**Rear %:**  
**Left %:**  
**Right %:**  
**Cross % (RF + LR):**  

---

## 4. Front Alignment

| Parameter | Left | Right |
|---|---:|---:|
| Castor | | |
| Camber | | |
| KPI / SAI | | |
| Individual Toe | | |

**Total Toe:**  
**Steering Center:**  
**Toe measurement method:**  

---

## 5. Rear Geometry

**Wheelbase left:**  
**Wheelbase right:**  
**Thrust Angle:**  
**Rear axle lateral offset:**  
**Panhard angle:**  
**Panhard length / setting:**  
**Shackle angle left:**  
**Shackle angle right:**  

---

## 6. Ackermann / Toe-Out-On-Turns

| Test | Inner wheel | Outer wheel | Difference |
|---|---:|---:|---:|
| Left turn | | | |
| Right turn | | | |

---

## 7. Bump Steer Summary

**LF max toe change in relevant travel:**  
**RF max toe change in relevant travel:**  
**Relevant bump travel:**  
**Relevant droop travel:**  
**Detailed curve file / sheet:**  

---

## 8. Driveline

**Transmission slope:**  
**Driveshaft slope:**  
**Pinion slope:**  
**Front U-joint operating angle:**  
**Rear U-joint operating angle:**  
**Difference:**  
**Wedge:**  

---

## 9. Tire Baseline

| Tire | Cold Pressure | Shore cold | Heat Cycles | Notes |
|---|---:|---:|---:|---|
| LF | | | | |
| RF | | | | |
| LR | | | | |
| RR | | | | |

---

## 10. Current Setup Classification

**Baseline ID:**  
**Primary handling state:**  
**Known asymmetries:**  
**Known limitations:**  
**Next planned test:**  
