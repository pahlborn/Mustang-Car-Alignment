# Longacre Scale Sheet

**Date:**  
**Scale model:**  
**Pad plane verified:** yes / no  
**Driver / ballast:**  
**Fuel:**  
**Cold tire pressure:**  
**ARB status:**  

---

## 1. Raw Weights

| Position | Attempt 1 | Attempt 2 | Attempt 3 |
|---|---:|---:|---:|
| LF | | | |
| RF | | | |
| LR | | | |
| RR | | | |
| Total | | | |

---

## 2. Percentages

| Metric | Value |
|---|---:|
| Front % | |
| Rear % | |
| Left % | |
| Right % | |
| Cross % (RF + LR) | |

---

## 3. Ride Height During Scaling

| Position | Height |
|---|---:|
| LF | |
| RF | |
| LR | |
| RR | |

---

## 4. Settling / Repeatability

**Settling procedure used:**  

**Max corner variation between attempts:**  
**Max total-weight variation:**  

- [ ] Repeatability acceptable
- [ ] Repeatability not acceptable — investigate

---

## 5. Adjustment Log

| Step | Adjustment | LF | RF | LR | RR | Cross % | Ride Height effect |
|---|---|---:|---:|---:|---:|---:|---|
| 0 | Baseline | | | | | | |
| 1 | | | | | | | |
| 2 | | | | | | | |
| 3 | | | | | | | |

---

## 6. ARB Preload Check

**Weights before reconnecting ARB:**  
**Weights after reconnecting ARB:**  

**Observed change:**  

- [ ] Neutral
- [ ] Preload present

---

## 7. Final Decision

**Target Cross:**  
**Achieved Cross:**  
**Ride Height acceptable:** yes / no  
**Any geometry compromised:** yes / no  

**Notes:**  
