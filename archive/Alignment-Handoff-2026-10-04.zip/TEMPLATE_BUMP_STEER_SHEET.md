# Bump Steer Measurement Sheet

**Date:**  
**Side:** LF / RF  
**Ride Height:**  
**Castor:**  
**Camber:**  
**Static Toe:**  
**Steering angle:** 0° / other  
**Steering locked:** yes / no  

**Sign convention:**  
Positive = Toe-in  
Negative = Toe-out

---

## 1. Measurement Table

| Wheel Travel | Toe Change | Direction | Notes |
|---:|---:|---|---|
| -50 mm | | | |
| -38 mm | | | |
| -25 mm | | | |
| -18 mm | | | |
| -12 mm | | | |
| -6 mm | | | |
| 0 mm | 0 | reference | |
| +6 mm | | | |
| +12 mm | | | |
| +18 mm | | | |
| +25 mm | | | |
| +38 mm | | | |
| +50 mm | | | |

---

## 2. Hardware State

**Tie rod / outer pivot:**  
**Spacer stack:**  
**Steering arm:**  
**Pitman arm:**  
**Idler arm:**  
**Center link:**  
**Bump steer kit:**  

---

## 3. Interpretation

**Relevant track travel window:**  
**Maximum toe-in in window:**  
**Maximum toe-out in window:**  
**Left/right symmetry:**  
**Curve monotonic:** yes / no  
**Zero crossing:**  

**Hypothesis:**  

---

## 4. Adjustment Iterations

| Iteration | Change | Result |
|---|---|---|
| 0 | Baseline | |
| 1 | | |
| 2 | | |
| 3 | | |

**Final curve accepted:** yes / no
