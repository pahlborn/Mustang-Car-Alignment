# Mustang Alignment Sheet

**Date:**  
**Race-ready state:**  
**Setup pad version:**  
**Tire set:**  
**Cold pressure:**  

---

## 1. Castor / Camber / KPI

| Parameter | LF | RF |
|---|---:|---:|
| Castor | | |
| Camber | | |
| KPI / SAI | | |

### Adjustment records

**LF UCA front shim:**  
**LF UCA rear shim:**  
**RF UCA front shim:**  
**RF UCA rear shim:**  

**LF Strut Rod setting:**  
**RF Strut Rod setting:**  

**LF LCA Camber Kit position:**  
**RF LCA Camber Kit position:**  

---

## 2. Toe

**Method:**  
- [ ] Longacre Toe Plates
- [ ] Scribed tire
- [ ] Strings
- [ ] Other

**Front distance F:**  
**Rear distance R:**  
**Total Toe = R − F:**  

| Wheel | Individual Toe |
|---|---:|
| LF | |
| RF | |

**Steering box centered:** yes / no  
**Steering wheel centered:** yes / no  

---

## 3. Ackermann

| Direction | Inner wheel | Outer wheel | Delta |
|---|---:|---:|---:|
| Left turn | | | |
| Right turn | | | |

**CG/6 zero checked:** yes / no

---

## 4. Final Verification

- [ ] Vehicle rolled back
- [ ] Vehicle rolled forward
- [ ] Suspension settled
- [ ] Castor rechecked
- [ ] Camber rechecked
- [ ] Total toe rechecked
- [ ] Individual toe rechecked
- [ ] Full lock clearance checked

**Notes:**  
