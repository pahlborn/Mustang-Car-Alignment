# Track Session Sheet

**Event:**  
**Track:**  
**Date:**  
**Session:**  
**Time:**  
**Driver:**  

**Weather:**  
**Air temp:**  
**Track temp:**  
**Dry / wet:**  

---

## 1. Tire State Before Stint

**Tire Set ID:**  
**Heat Cycles:**  

| Tire | Cold Pressure | Shore cold |
|---|---:|---:|
| LF | | |
| RF | | |
| LR | | |
| RR | | |

---

## 2. Chassis Baseline

**Camber L/R:**  
**Castor L/R:**  
**Total Toe:**  
**Cross %:**  
**Ride Height:**  
**Panhard setting:**  
**Other relevant setup:**  

---

## 3. Stint

**Laps:**  
**Best lap:**  
**Average representative lap:**  
**Fuel start:**  
**Fuel end:**  

---

## 4. Post-Stint Measurements

### Hot Pressure

| Tire | Hot Pressure | Gain |
|---|---:|---:|
| LF | | |
| RF | | |
| LR | | |
| RR | | |

### Pyrometer

| Tire | Outside | Middle | Inside |
|---|---:|---:|---:|
| LF | | | |
| RF | | | |
| LR | | | |
| RR | | | |

**Time from pit stop to first measurement:**  
**Measurement order:** RF → RR → LR → LF

---

## 5. Tire Appearance

**LF:**  
**RF:**  
**LR:**  
**RR:**  

Photo references:  

---

## 6. Driver Feedback

Rate 1–5 and add comments.

| Category | Score | Comments |
|---|---:|---|
| Steering response | | |
| Stability | | |
| Balance | | |
| Breakaway | | |
| Traction | | |
| Confidence | | |

### Corner phases

**Braking:**  
**Initial Turn-in:**  
**Entry / Trail:**  
**Mid-Corner:**  
**Initial Throttle:**  
**Exit:**  
**High-Speed:**  
**Kerbs / Bumps:**  

---

## 7. Symptom Codes

- [ ] BRAKE-INSTABILITY
- [ ] ENTRY-US
- [ ] ENTRY-OS
- [ ] MID-US
- [ ] MID-OS
- [ ] POWER-US
- [ ] POWER-OS
- [ ] HIGH-SPEED-US
- [ ] HIGH-SPEED-OS
- [ ] BUMP-INSTABILITY
- [ ] L/R-ASYMMETRY
- [ ] DEGRADES-WITH-LAPS

---

## 8. Interpretation

**Earliest problematic phase:**  
**Most relevant objective data:**  
**Probable cause family:**  

- [ ] Tire
- [ ] Alignment
- [ ] Balance
- [ ] Kinematics
- [ ] Front roll / damping
- [ ] Rear roll / damping
- [ ] Driver input
- [ ] Mechanical problem
- [ ] Unknown

**Hypothesis:**  
