# Setup Change Log

**Change ID:**  
**Date:**  
**Track / workshop:**  
**Baseline ID:**  
**Session A:**  
**Session B:**  

---

## 1. Problem Statement

**Symptom code:**  
**Corner phase:**  
**Where does it occur:**  
**How reproducible is it:**  

---

## 2. Evidence

### Tire
**Cold / Hot pressure:**  
**Pyrometer:**  
**Shore / age:**  
**Tire appearance:**  

### Chassis
**Ride Height:**  
**Corner Weights / Cross:**  
**Camber:**  
**Castor:**  
**Toe:**  
**Thrust:**  
**Bump Steer:**  
**Ackermann:**  

### Driver
**Feedback:**  

---

## 3. Hypothesis

**Suspected cause:**  

**Why this cause fits the data:**  

**Alternative explanations:**  

---

## 4. Planned Change

**Exactly one primary change:**  

**Old value:**  
**New value:**  

**Expected primary effect:**  
**Expected side effects:**  
**What could get worse:**  

---

## 5. Success Criteria

**Objective metric:**  
**Driver metric:**  
**Lap / sector metric:**  
**Abort criterion:**  

---

## 6. A/B Result

### A — Before
**Conditions:**  
**Result:**  

### B — After
**Conditions:**  
**Result:**  

---

## 7. Decision

- [ ] Keep change
- [ ] Revert
- [ ] Repeat test
- [ ] Inconclusive
- [ ] Investigate another cause

**Reason:**  

**New Baseline ID if accepted:**  
