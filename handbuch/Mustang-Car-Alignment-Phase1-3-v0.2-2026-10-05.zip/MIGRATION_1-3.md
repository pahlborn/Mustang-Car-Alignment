# Strukturmaßnahmen 1–3 — Migration Note

**Dokumentrolle:** Temporäres Migrations- und Auditprotokoll  
**Version:** 0.2  
**Datum:** 2026-10-05  
**Status:** Aktiv bis Abschluss der Strukturmigration; danach nach `archive/` verschieben

---

## 1. Zweck und Lebenszyklus

Diese Datei dokumentiert ausschließlich die Umstellung vom bisherigen losen Dateibestand auf eindeutige Autoritäten.

Sie ist **kein dauerhaftes Fach- oder Governance-Dokument**. Nach Abschluss der Strukturmaßnahmen und Übernahme aller relevanten Altinhalte wird sie als Migrationsnachweis nach `archive/` verschoben.

---

## 2. Neue Autoritätskette

Bei Widersprüchen gilt:

1. [`CONVENTIONS.md`](CONVENTIONS.md) — Definitionen, Vorzeichen, Formeln, IDs, Statusvokabular
2. [`00_PROJECT.md`](00_PROJECT.md) — konkretes Fahrzeug, Hardware, Messmittel, Baseline, offene Fahrzeugdaten
3. [`02_WORKFLOW.md`](02_WORKFLOW.md) — Reihenfolge, Rückkopplungen und Gesamtprozess

Diese drei Rollen überlappen sich nicht.

---

## 3. Maßnahme 1 — `CONVENTIONS.md`

Neu angelegt als einzige Autorität für:

- Radpositionskürzel
- Einheiten
- Camber-/Castor-Vorzeichen
- Toe-Formel und Toe-Vorzeichen
- Bump-Steer-Vorzeichen
- Corner-Weight-Formeln
- Dunlop IN/OUT
- Driveline UP/DOWN
- Baseline/Target/Messwert
- Evidenzgrade
- Verifizierungsstatus für Projektdaten
- Symptomcodes
- Baseline-/Change-/Session-IDs

Noch nicht festgelegte Richtungen werden ausdrücklich als offen geführt, darunter Thrust Angle, Panhard Offset und Rake.

---

## 4. Maßnahme 2 — `00_PROJECT.md`

Neu angelegt als einzige Autorität für:

- konkretes Fahrzeug
- aktuelle bzw. im Projekt dokumentierte Hardware
- Messmittel
- aktuelle Baseline
- bekannte Fahrzeugauffälligkeiten
- offene Hardware- und Messdaten

Die Alignment-/Reifendruck-Baseline wird künftig nur dort gepflegt.

### In Phase 1–3 neu aus dem bisherigen Nutzer-/Projektkontext erfasste Angaben

Folgende Angaben waren **nicht in allen übergebenen temp-Dateien belegt**, sondern wurden aus dem bereits vorhandenen Nutzer-/Projektkontext übernommen. Sie sind deshalb in `00_PROJECT.md` als `Projektangabe` und nicht als neu physisch verifizierte Messung gekennzeichnet:

- Steering Box: Flaming River FR1497-1Q, 1" sector, 16:1
- Differential: Eaton TrueTrac
- Achsübersetzung: 3.50:1
- Reifenbezeichnung einschließlich `99V`
- Streckenkontext: Pannoniaring, Slovakiaring, Brno

Jerico DR4 war zusätzlich bereits in Legacy-Unterlagen dokumentiert.

Diese Aufnahme war ein Scope-Zuwachs gegenüber einer rein mechanischen Konsolidierung; die Kennzeichnung macht ihn nun auditierbar.

---

## 5. Maßnahme 3 — `02_WORKFLOW.md`

`MASTER_WORKFLOW_MUSTANG_TRACK_CHASSIS_SETUP.md` wurde als Prozessautorität übernommen.

Bereinigt wurden:

- genau ein Dokumentheader
- genau ein H1
- Hauptabschnitte als H2
- Unterabschnitte als H3
- konkrete Fahrzeughardware aus Phase 0 → Verweis auf `00_PROJECT.md`
- Symptomcode-Definition → Verweis auf `CONVENTIONS.md`
- `FL/FR/RL/RR` → `LF/RF/LR/RR`
- `Baseline V1` → ID-/Governance-Verweis auf `CONVENTIONS.md` und `00_PROJECT.md`
- konkrete Messgerätemodelle in operativen Schritten → generische Messmittelbezeichnungen
- doppelte Prioritätsliste in Phase 8 → Verweis auf das eine Prioritätsmodell in Abschnitt 29

Hersteller-/Quellennamen dürfen in Begründungs- und Quellenabschnitten weiterhin genannt werden; die konkrete am Fahrzeug vorhandene Hardware wird nur in `00_PROJECT.md` gepflegt.

---

## 6. Mapping aus den Altdateien

Dieses Mapping verhindert, dass bei der späteren Archivierung erneut analysiert werden muss, welche Altabschnitte bereits ersetzt wurden.

| Altdatei / Abschnitt | Neue Autorität | Status |
|---|---|---|
| `MASTER_CONCEPT.md` §2 Fahrzeugkontext | `00_PROJECT.md` §2–7 | strukturell ersetzt |
| `MASTER_CONCEPT.md` §3 aktuelle Baseline | `00_PROJECT.md` §8–10 | ersetzt |
| `MASTER_CONCEPT.md` §14 Evidenzsystem | `CONVENTIONS.md` Evidenzgrade | Konventionsteil ersetzt; Architekturanteil bleibt für `01_ARCHITECTURE.md` |
| `MASTER_CONCEPT.md` §10.2 Adjustment Cycle | `02_WORKFLOW.md` | Prozessrolle ersetzt |
| `CONTENT_SPECIFICATION.md` §12 Complete Setup Procedure | `02_WORKFLOW.md` | Prozessrolle ersetzt; Seitenspezifikation bleibt für `01_ARCHITECTURE.md` |
| `MASTER_WORKFLOW_MUSTANG_TRACK_CHASSIS_SETUP.md` gesamt | `02_WORKFLOW.md` | ersetzt / neue Prozessautorität |
| `mustang-1966-track-alignment.md` §18 kompletter Werkstattablauf | `02_WORKFLOW.md` | Prozessrolle ersetzt; Fachinhalte noch nicht vollständig migriert |
| `HANDOFF_MUSTANG_CAR_ALIGNMENT.md` Fahrzeug/Baseline/Workflow-Zusammenfassung | `00_PROJECT.md` + `02_WORKFLOW.md` | ersetzt; später archivieren |
| Fachkapitel: verstreute Toe/Cross/Dunlop/Driveline-Konventionen | `CONVENTIONS.md` | Definitionen ersetzt; Fachtexte noch nicht bereinigt |

---

## 7. Bewusst noch nicht geändert

Die Altdateien selbst wurden noch nicht umgebaut oder archiviert. Deshalb enthalten sie weiterhin redundante Daten und Abläufe.

Noch offen:

- `01_ARCHITECTURE.md`
- physisches Entfernen/Ersetzen redundanter Altpassagen
- Archivierung von Handoff und V1-Werkstattdokument
- Citation-Artefakte in Rear-/Toe-Kapiteln
- Thrust-Konsolidierung
- Trennung Setup Pad / Ride Height
- projektweite Querverlinkung und Index/Statusmatrix
- fehlende Learn-/Mustang-Kapitel

Diese Punkte gehören ausdrücklich **nicht** zu Phase 1–3.
