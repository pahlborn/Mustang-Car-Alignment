# Mustang Track Chassis Setup — Project

**Dokumentrolle:** Single Source of Truth für das konkrete Fahrzeug  
**Version:** 0.2  
**Datum:** 2026-10-05  
**Status:** Autoritativ für Fahrzeugdaten, Hardware, Messmittel und aktuelle Baseline

---

## 1. Zweck

Diese Datei enthält ausschließlich den **konkreten Projektzustand des Fahrzeugs**.

Fachkapitel dürfen diese Daten erläutern oder auf sie verweisen, aber Fahrzeughardware, Baseline-Zahlen und bekannte Fahrzeugauffälligkeiten werden nur hier verbindlich gepflegt.

Konventionen und Formeln: siehe [`CONVENTIONS.md`](CONVENTIONS.md).  
Verbindlicher Setup-Ablauf: siehe [`02_WORKFLOW.md`](02_WORKFLOW.md).

---

## 2. Fahrzeug

| Merkmal | Projektstand |
|---|---|
| Fahrzeug | Ford Mustang |
| Modelljahr | 1966 |
| Einsatz | Rennstrecke / Track |
| Strecken | Pannoniaring, Slovakiaring, Brno |
| Lenkung | Manual Steering |
| Hinterachse | Ford 9" |

---

## 3. Vorderachse / Lenkung

**Statusvokabular:** siehe [`CONVENTIONS.md`](CONVENTIONS.md) §17. In Phase 1–3 wurden vorhandene Projektangaben konsolidiert, nicht physisch am Fahrzeug neu verifiziert.

| Bauteil / Geometrie | Projektstand | Status |
|---|---|---|
| Shelby Drop | vorhanden | Projektangabe |
| LCA Camber Kit | Street or Track | Projektangabe |
| Strut Rods | einstellbar; Global West im Projekt dokumentiert | Projektangabe; Modell/Version offen |
| Ball Joints | Howe | Projektangabe |
| Steering Box | Flaming River FR1497-1Q, 1" sector, 16:1 | Projektangabe |
| UCA | genaue aktuelle Ausführung noch erfassen | Offen |
| Federn | genaue Rate/Ausführung noch erfassen | Offen |
| Dämpfer | genaue Ausführung/Einstellung noch erfassen | Offen |
| Front ARB / Endlinks | genaue Hardware und Preload-Zustand erfassen | Offen |
| Steering Arms / Tie Rods / Center Link / Idler / Pitman | Ist-Zustand vollständig inventarisieren | Offen |

### Alignment-relevante Regel

Änderungen an UCA, Strut Rod, LCA/Camber Kit, Ball-Joint-Geometrie oder Ride Height können mehrere Größen gleichzeitig beeinflussen. Nach Änderungen werden die abhängigen Größen gemäß [`02_WORKFLOW.md`](02_WORKFLOW.md) erneut geprüft.

---

## 4. Hinterachse

| Bauteil / Geometrie | Projektstand | Status |
|---|---|---|
| Achse | Ford 9" | Projektangabe |
| Differential | Eaton TrueTrac | Projektangabe |
| Achsübersetzung | 3.50:1 | Projektangabe |
| Federung | Blattfedern | Projektangabe |
| Federhistorie | 4-leaf Reverse-Eye → Mid-Eye | Legacy-Angabe |
| Panhard Bar | vorhanden; Maier-Kontext | Projektangabe; Geometrie/Höhe offen |
| Bushings | Projekt enthält Diskussion Delrin/Del-A-Lum-artiger Lösungen | Legacy-Angabe; aktuelle Bestückung offen |
| Shackles | aktuelle Geometrie/Winkel vermessen | Offen |
| U-Bolts / Spring Plates | Zustand/Hardware dokumentieren | Offen |
| Rear ARB | nicht als vorhanden bestätigt | Offen |

### Bekannte Beobachtung

Im Projekt wurde die linke Heckseite wiederholt mit ungefähr **20 mm geringerer Ride Height** beschrieben.

Status: **Beobachtung / erneut reproduzierbar vermessen; Ursache nicht festgelegt.**

Keine Korrekturmaßnahme allein aus dieser Beobachtung ableiten.

---

## 5. Driveline

| Bauteil | Projektstand |
|---|---|
| Getriebe | Jerico DR4 im aktuellen Rennfahrzeug-Projekt |
| Hinterachse | Ford 9", 3.50:1 |
| Kardanwelle | Projekt enthält 3"/3.5"-Diskussion; aktuelle verbaute Ausführung verifizieren |
| U-Joints | genaue Ausführung dokumentieren |
| Pinion / Yoke | Winkel vollständig neu vermessen |

### Legacy-/Arbeitswerte

Frühere Projektdiskussionen enthielten ungefähr:

- Transmission/Output: `~3,5° DOWN`
- Pinion: `~1° DOWN`
- 2° Wedge, dicke Seite vorn, als Hersteller-/Projektkontext

Diese Werte sind **keine aktuelle Sollvorgabe**. Für die verbindliche Bewertung müssen Transmission-, Driveshaft- und Pinion-Slope sowie beide U-Joint Operating Angles neu gemessen werden.

---

## 6. Räder und Reifen

| Merkmal | Projektstand |
|---|---|
| Räder | American Racing 15×7 |
| Reifen | Avon CR6ZZ 225/65 R15 99V |
| Warmdruck-Baseline | 2,2 bar |
| Tire Set ID | noch einzuführen |
| Heat Cycles | noch systematisch zu erfassen |
| Shore-Historie | noch systematisch zu erfassen |

`2,2 bar` ist eine **Baseline**, kein abschließend validierter Optimalwert.

---

## 7. Messmittel

Vorhanden:

- Dunlop CG/4-5 Castor/Camber/KPI Gauge
- Dunlop CG/6 Steering Turntables
- Longacre kabelgebundene Corner-Weight-Waagen
- Longacre Toe Plates
- Longacre digitaler Reifendruckprüfer
- Longacre Probe-Pyrometer / Einstichsonde
- Shore-A-Messgerät / Tire Durometer
- Standardwerkstatt-Messmittel / Messbänder
- String Alignment als ergänzendes Verfahren vorgesehen

Noch zu erfassen:

- exaktes Longacre-Waagenmodell
- exakte Spezifikation/Modell des Pyrometers
- vorhandenes bzw. endgültig ausgewähltes Bump-Steer-Gauge

---

## 8. Aktuelle Baseline

**Baseline-Status:** Referenzzustand aus bisherigem Projekt; noch nicht als vollständig neu vermessene Baseline-ID eingefroren.

| Parameter | Referenzwert | Klassifikation |
|---|---:|---|
| Castor | +3,0° | Baseline |
| Camber | −2,0° | Baseline |
| Total Toe | +1,6 mm Toe-in *(≈ 1/16", Umrechnung/Referenz)* | Baseline |
| Reifen-Warmdruck | 2,2 bar | Baseline |

Diese Werte sind **keine automatische Track-Zielvorgabe**.

Herstellerbeispiele, Straßenempfehlungen und später am Fahrzeug validierte Zielwerte werden separat geführt.

---

## 9. Noch nicht vorhandene verbindliche Fahrzeugmesswerte

Folgende Daten fehlen für eine vollständige Baseline:

### Ride Height
- LF
- RF
- LR
- RR
- definierte Messpunkte
- Rake
- Bump-Stop-Clearance

### Corner Weight
- LF
- RF
- LR
- RR
- Total
- Front/Rear %
- Left/Right %
- Cross %

### Rear Geometry
- Wheelbase links/rechts
- Thrust Angle
- Achs-Lateralposition
- Panhard-Länge
- Panhard-Höhe/Winkel
- Shackle-Winkel

### Kinematics
- LF Bump-Steer-Kurve
- RF Bump-Steer-Kurve
- relevante reale Bump-/Droop-Travel-Range
- Camber Gain, falls gemessen

### Steering
- KPI/SAI links/rechts
- Ackermann links/rechts
- Full-Lock-Freigängigkeit

### Driveline
- Transmission Slope
- Driveshaft Slope
- Pinion Slope
- Front Operating Angle
- Rear Operating Angle

---

## 10. Baseline-Governance

Sobald das Fahrzeug nach [`02_WORKFLOW.md`](02_WORKFLOW.md) vollständig vermessen wurde:

1. Baseline-ID nach [`CONVENTIONS.md`](CONVENTIONS.md) vergeben.
2. Race-Ready-Zustand dokumentieren.
3. Setup-Pad-Version dokumentieren.
4. Hardwarezustand einfrieren.
5. Alignment, Ride Height, Corner Weight, Rear Geometry und Reifenstatus erfassen.
6. Nur diese vollständige Kombination gilt als eingefrorene Baseline.

Eine einzelne Alignment-Zahl allein ist keine vollständige Fahrzeug-Baseline.

---

## 11. Offene Hardwarefragen

Vor einer endgültigen technischen Veröffentlichung noch verifizieren:

- exakte UCA-Ausführung
- exakte Shelby-Drop-Ausführung/Bohrposition
- exakte Global-West-Strut-Rod-Ausführung
- aktuelle LCA-Camber-Kit-Position
- Frontfeder-Ausführung und Rate
- Front-ARB und Endlinks
- Dämpfer
- aktuelle Mid-Eye-Blattfeder: Hersteller/Rate/Blattzahl
- aktuelle Bushings
- Panhard-Abmessungen und Befestigungshöhen
- aktuelle Kardanwelle
- exaktes Longacre-Waagenmodell
- tatsächliche Möglichkeiten zur Ride-Height-/Corner-Weight-Verstellung am Fahrzeug

---

## 12. Änderungsregel

Änderungen an Fahrzeugdaten, Hardware oder Baseline werden **zuerst hier** eingetragen.

Andere Dokumente sollen keine unabhängigen Kopien dieser Daten pflegen, sondern auf diese Datei verweisen.
